function sol = solve_ballooning_eigenvalue(bal, varargin)
%SOLVE_BALLOONING_EIGENVALUE Solve ideal ballooning eigenvalue problem.
%
%   sol = solve_ballooning_eigenvalue(bal)
%   sol = solve_ballooning_eigenvalue(bal,'Name',value,...)
%
% Input
%   bal : output of eq_ballooning_coefficients.m, must contain
%         bal.theta, bal.g, bal.c, bal.f on one poloidal period [0,2pi)
%
% Solves
%   d/dtheta ( g dX/dtheta ) + c X = lambda f X
%
% on theta_b in [-ThetaB, ThetaB] with X(-ThetaB)=X(ThetaB)=0.
%
% The periodic equilibrium coefficients are extended along the field line.
%
% Name-value options
%   ThetaB        : ballooning domain half-width, default 5*pi
%   N             : number of total grid points including boundaries, default 501
%                   Use odd N as in the paper. Interior unknowns are N-2.
%   AlphaShift    : theta shift theta0, default 0
%   NEigs         : number of eigenvalues requested, default 6
%   Which         : eigs selector, default 'largestreal'
%   UseSparse     : use sparse matrix, default true
%   RefineRayleigh: recompute lambda with variational/Rayleigh quotient, default true
%   Plot          : true/false, default false
%
% Output
%   sol.lambda          : selected eigenvalue from matrix solve
%   sol.lambda_refined  : Rayleigh quotient value using returned eigenfunction
%   sol.theta_b         : full ballooning grid including boundaries
%   sol.X               : eigenfunction including zero boundaries
%   sol.A               : discretized operator for interior points
%   sol.theta_int       : interior theta grid
%   sol.g, sol.c, sol.f : coefficients on full grid
%   sol.g_half          : g at half points
%
% Notes
%   Matrix convention used here:
%       K X = lambda M X
%   where K discretizes d/dtheta(g dX/dtheta) + c X and M=diag(f).
%   This convention is consistent with the Rayleigh quotient
%       lambda = int(c|X|^2 - g|X'|^2)/int(f|X|^2).

    p = inputParser;
    addParameter(p, 'ThetaB', 5*pi, @(x)isnumeric(x)&&isscalar(x)&&x>0);
    addParameter(p, 'N', 501, @(x)isnumeric(x)&&isscalar(x)&&x>=5);
    addParameter(p, 'AlphaShift', 0, @(x)isnumeric(x)&&isscalar(x));
    addParameter(p, 'NEigs', 6, @(x)isnumeric(x)&&isscalar(x)&&x>=1);
    addParameter(p, 'Which', 'largestreal', @(x)ischar(x)||isstring(x));
    addParameter(p, 'UseSparse', true, @(x)islogical(x)&&isscalar(x));
    addParameter(p, 'RefineRayleigh', true, @(x)islogical(x)&&isscalar(x));
    addParameter(p, 'Plot', false, @(x)islogical(x)&&isscalar(x));
    parse(p, varargin{:});
    opt = p.Results;

    N = round(opt.N);
    if mod(N,2) == 0
        warning('solve_ballooning_eigenvalue:EvenN', ...
            'N should be odd. Changing N=%d to N=%d.', N, N+1);
        N = N + 1;
    end

    theta_b = linspace(-opt.ThetaB, opt.ThetaB, N).';
    dth = theta_b(2) - theta_b(1);

    % Periodically extend one-period coefficients onto ballooning coordinate.
    [g, c, f] = interpolate_periodic_coefficients(bal.theta(:), bal.g(:), bal.c(:), bal.f(:), ...
                                                   theta_b + opt.AlphaShift);

    % Half-point g values: g_{j+1/2}, between full points j and j+1.
    theta_half = 0.5*(theta_b(1:end-1) + theta_b(2:end));
    [g_half, ~, ~] = interpolate_periodic_coefficients(bal.theta(:), bal.g(:), bal.c(:), bal.f(:), ...
                                                       theta_half + opt.AlphaShift);

    % Unknowns are interior full-grid points: j = 2,...,N-1 in MATLAB indexing.
    M = N - 2;
    theta_int = theta_b(2:end-1);
    c_int = c(2:end-1);
    f_int = f(2:end-1);

    lowerK = zeros(M,1);
    diagK  = zeros(M,1);
    upperK = zeros(M,1);

    for m = 1:M
        % Physical full-grid index j = m+1.
        % g_minus = g_{j-1/2}; g_plus = g_{j+1/2}.
        g_minus = g_half(m);
        g_plus  = g_half(m+1);
        cj = c_int(m);

        % Discretization of
        %   d/dtheta(g dX/dtheta) + c X = lambda f X
        % gives
        %   K(j,j-1)= g_minus/dtheta^2
        %   K(j,j)  = c_j - (g_minus+g_plus)/dtheta^2
        %   K(j,j+1)= g_plus/dtheta^2
        diagK(m) = cj - (g_minus + g_plus)/dth^2;
        if m > 1
            lowerK(m) = g_minus/dth^2;
        end
        if m < M
            upperK(m) = g_plus/dth^2;
        end
    end

    if opt.UseSparse
        K = spdiags([[lowerK(2:end);0], diagK, [0;upperK(1:end-1)]], -1:1, M, M);
        Mmat = spdiags(f_int, 0, M, M);
    else
        K = diag(diagK) + diag(upperK(1:end-1),1) + diag(lowerK(2:end),-1);
        Mmat = diag(f_int);
    end

    % For backward compatibility, A stores the divided operator inv(M)*K.
    A = Mmat \ K;

    % eigs option string differs across MATLAB versions. Try robustly.
    neigs = min(round(opt.NEigs), M-2);
    which = char(opt.Which);

    try
        [V,D] = eigs(K, Mmat, neigs, which);
        evals = diag(D);
    catch
        % Fallback: full eigenvalue solve for moderate matrix sizes.
        [V,D] = eig(full(K), full(Mmat));
        evals = diag(D);
    end

    % Pick largest real part eigenvalue.
    [~, imax] = max(real(evals));
    lambda = evals(imax);
    Xint = V(:,imax);

    % Normalize sign/scale.
    X = [0; Xint; 0];
    [~, im] = max(abs(X));
    X = X / X(im);
    if real(X(im)) < 0
        X = -X;
    end
    X = real(X);

    lambda_refined = NaN;
    if opt.RefineRayleigh
        lambda_refined = rayleigh_refine(theta_b, X, g, c, f);
    end

    sol = struct();
    sol.lambda = lambda;
    sol.lambda_refined = lambda_refined;
    sol.theta_b = theta_b;
    sol.theta_int = theta_int;
    sol.X = X;
    sol.A = A;
    sol.K = K;
    sol.M = Mmat;
    sol.g = g;
    sol.c = c;
    sol.f = f;
    sol.g_half = g_half;
    sol.dtheta = dth;
    sol.options = opt;

    if opt.Plot
        figure;
        plot(theta_b, X, 'LineWidth', 1.5);
        grid on;
        xlabel('\theta_b');
        ylabel('X');
        title(sprintf('Ballooning eigenfunction, lambda = %.6g, refined = %.6g', ...
            real(lambda), lambda_refined));
    end
end

%==========================================================================
function [gq, cq, fq] = interpolate_periodic_coefficients(theta, g, c, f, thetaq)
    theta = theta(:);
    g = g(:); c = c(:); f = f(:);

    % Map input theta to [0,2pi), sort and remove duplicates.
    th = mod(theta, 2*pi);
    [th, idx] = sort(th);
    g = g(idx); c = c(idx); f = f(idx);
    [th, g, c, f] = unique_periodic_samples(th, g, c, f);

    % Periodic extension for smooth interpolation across branch cut.
    th_ext = [th-2*pi; th; th+2*pi];
    g_ext  = [g; g; g];
    c_ext  = [c; c; c];
    f_ext  = [f; f; f];

    tq = mod(thetaq(:), 2*pi);

    gq = interp1(th_ext, g_ext, tq, 'pchip');
    cq = interp1(th_ext, c_ext, tq, 'pchip');
    fq = interp1(th_ext, f_ext, tq, 'pchip');
end

%==========================================================================
function [th_u, g_u, c_u, f_u] = unique_periodic_samples(th, g, c, f)
    tol = 1e-12;
    key = round(th/tol)*tol;
    [~,~,ic] = unique(key, 'stable');
    n = max(ic);
    th_u = zeros(n,1); g_u = zeros(n,1); c_u = zeros(n,1); f_u = zeros(n,1);
    for k = 1:n
        m = ic == k;
        th_u(k) = mean(th(m));
        g_u(k)  = mean(g(m), 'omitnan');
        c_u(k)  = mean(c(m), 'omitnan');
        f_u(k)  = mean(f(m), 'omitnan');
    end

    % Remove possible 2pi duplicate of 0.
    if numel(th_u) > 1 && abs((th_u(end)-th_u(1)) - 2*pi) < 1e-10
        th_u(end) = [];
        g_u(end) = [];
        c_u(end) = [];
        f_u(end) = [];
    end
end

%==========================================================================
function lam = rayleigh_refine(theta, X, g, c, f)
    % Fourth-order-ish derivative where possible; gradient handles boundaries.
    dX = fourth_order_derivative_uniform(theta, X);
    num = simpson_or_trapz(theta, c.*abs(X).^2 - g.*abs(dX).^2);
    den = simpson_or_trapz(theta, f.*abs(X).^2);
    lam = num / den;
end

%==========================================================================
function dY = fourth_order_derivative_uniform(x, y)
    x = x(:); y = y(:);
    n = numel(y);
    h = x(2)-x(1);
    dY = zeros(n,1);

    if n < 5
        dY = gradient(y,h);
        return;
    end

    % 4th-order centered interior.
    for i = 3:n-2
        dY(i) = (y(i-2) - 8*y(i-1) + 8*y(i+1) - y(i+2)) / (12*h);
    end

    % 2nd-order one-sided near boundaries.
    dY(1)   = (-3*y(1) + 4*y(2) - y(3)) / (2*h);
    dY(2)   = (y(3) - y(1)) / (2*h);
    dY(n-1) = (y(n) - y(n-2)) / (2*h);
    dY(n)   = (3*y(n) - 4*y(n-1) + y(n-2)) / (2*h);
end

%==========================================================================
function I = simpson_or_trapz(x, y)
    x = x(:); y = y(:);
    n = numel(x);
    h = x(2)-x(1);

    % Simpson 1/3 needs odd number of points, even number of intervals.
    if mod(n,2) == 1
        I = h/3 * (y(1) + y(end) + 4*sum(y(2:2:end-1)) + 2*sum(y(3:2:end-2)));
    else
        % Simpson on first n-1 points + trapezoid on last interval.
        I = h/3 * (y(1) + y(end-1) + 4*sum(y(2:2:end-2)) + 2*sum(y(3:2:end-3))) ...
            + h*(y(end-1)+y(end))/2;
    end
end
